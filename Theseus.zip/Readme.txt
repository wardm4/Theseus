The Minotaur chases you through his labyrinth while you try to find your way to the center to kill him!

1. Move with arrow keys.

2. Special items are one-time use. Activate with spacebar.

3. All other "actions" are done with "x" (rest, travel to another zone, get off startscreen, etc).

4. Esc quits the game! Do NOT hit Esc if you try to leave a screen. Always progress with "x" if in doubt.
